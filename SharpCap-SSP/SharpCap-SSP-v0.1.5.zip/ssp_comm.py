"""
SSP Serial Communication
========================

Handles serial communication with SSP photometer.
Implements the SSP-3a/SSP-5a serial protocol.

Author: pep-ssp-tools project
Version: 0.1.2
"""

import clr
clr.AddReference('System')

# Try to import serial port functionality
# In IronPython 3.4 (.NET Core/5+), System.IO.Ports is a separate package
SERIAL_AVAILABLE = False
try:
    from System.IO.Ports import SerialPort, Parity, StopBits
    SERIAL_AVAILABLE = True
except ImportError:
    SerialPort = None
    Parity = None
    StopBits = None

from System.Threading import Thread
from System import TimeSpan, DateTime, Array, Byte
import time


class SSPCommunicator:
    """Manages serial communication with SSP photometer."""
    
    def __init__(self, boot_delay=5.0, device_type='auto', config=None):
        """Initialize communicator.
        
        Args:
            boot_delay: Seconds to wait after opening COM port before sending 
                       SSSSSS command. Arduino Uno bootloader takes ~2 seconds
                       to complete. Default 5.0 seconds provides extra margin.
            device_type: 'auto', 'ssp3', or 'ssp5a' - configurable device type
            config: SSPConfig instance for accessing configuration
        """
        self.port = None
        self.is_connected = False
        self.port_name = ""
        self.buffer_size = 32768
        self.boot_delay = boot_delay  # Wait for Arduino bootloader
        self.device_type = device_type  # 'auto', 'ssp3', 'ssp5a'
        self.detected_device_type = 'unknown'  # 'unknown', 'ssp3', 'ssp5a'
        self.config = config  # SSPConfig instance
        
        print(f"[SSP] Communicator initialized with boot delay: {self.boot_delay} seconds")
        print(f"[SSP] Device type configured as: {self.device_type}")
    
    def _try_connect_with_params(self, com_port_number, boot_delay=0.5, wait_iterations=100, description="SSP3 timing"):
        """Internal helper to try connection with specific parameters.
        
        Args:
            com_port_number: COM port number
            boot_delay: Seconds to wait after opening COM port
            wait_iterations: Number of 50ms iterations to wait for response
            description: Description of this connection attempt for logging
            
        Returns:
            tuple: (success: bool, message: str)
        """
        try:
            print(f"[SSP] Trying connection with {description}: boot_delay={boot_delay}s, wait={wait_iterations*0.05}s")
            
            self.port_name = "COM" + str(com_port_number)
            
            # Open serial port with SSP parameters
            self.port = SerialPort(self.port_name, 19200, getattr(Parity, 'None'), 8, StopBits.One)
            self.port.ReadBufferSize = self.buffer_size
            self.port.WriteBufferSize = self.buffer_size
            self.port.ReadTimeout = 5000  # 5 second timeout
            self.port.WriteTimeout = 1000  # 1 second timeout
            self.port.Open()
            
            # Wait for bootloader if specified
            if boot_delay > 0:
                print(f"[SSP] Waiting {boot_delay} seconds {description}...")
                time.sleep(boot_delay)
            
            # Clear any leftover data in serial buffer
            print(f"[SSP] Clearing serial buffer...")
            self._clear_buffer()
            
            # Send initialization command
            print(f"[SSP] Sending initialization command: SSSSSS")
            self._write("SSSSSS")
            
            # Wait for acknowledgment (original SSPDataq: 100 iterations × 50ms = 5 seconds)
            data_parts = []  # Use list for accumulation
            for i in range(wait_iterations):
                time.sleep(0.05)  # 50ms pause
                if self.port.BytesToRead > 0:
                    chunk = self._read_available()
                    if chunk:
                        data_parts.append(chunk)
                
                # Check if we have enough data
                if data_parts:
                    data_joined = ''.join(data_parts)  # Join to check
                    if "!" in data_joined or chr(10) in data_joined:
                        # Store the joined data for later use
                        data_read = data_joined
                        break
            
            # Join all parts if we haven't already
            if data_parts and 'data_read' not in locals():
                data_read = ''.join(data_parts)
            
            # Check for valid response
            if data_parts:  # Check if we have any data
                if "!" in data_read:
                    self.is_connected = True
                    return (True, f"Connected to {self.port_name} with {description}")
                elif chr(10) in data_read:
                    self.is_connected = True
                    return (True, f"Connected to {self.port_name} with {description}")
                else:
                    pass
            
            # Connection failed
            if self.port and self.port.IsOpen:
                self.port.Close()
            self.port = None
            return (False, f"No response with {description}")
            
        except Exception as e:
            if self.port and self.port.IsOpen:
                self.port.Close()
            self.port = None
            return (False, f"Connection error with {description}: {str(e)}")
    
    def connect(self, com_port_number):
        """Connect to SSP photometer with progressive fallback.
        
        Implements progressive fallback for SSP3/SSP5A compatibility:
        1. Try SSP3 timing first (minimal boot delay, original SSPDataq timing)
        2. If fails, try SSP5A timing (5s boot delay, shorter wait)
        
        Args:
            com_port_number: COM port number (1-19)
            
        Returns:
            tuple: (success: bool, message: str)
        """
        if not SERIAL_AVAILABLE:
            return (False, "Serial port functionality not available. Install System.IO.Ports package.")
        
        if self.is_connected:
            return (False, "Already connected")
        
        if com_port_number == 0:
            return (False, "Please select a COM port in Setup menu")
        
        # Reset detected device type
        self.detected_device_type = 'unknown'
        
        # Handle manual device type selection
        if self.device_type == 'ssp3':
            print(f"[SSP] Using manual SSP3 timing (no progressive fallback)")
            # Try SSP3 timing only
            success, message = self._try_connect_with_params(
                com_port_number, 
                boot_delay=0.5,  # Minimal delay
                wait_iterations=100,  # Original SSPDataq: 5 seconds total
                description="SSP3 timing (manual)"
            )
            if success:
                self.detected_device_type = 'ssp3'
                if self.config:
                    self.config.config['detected_device_type'] = 'ssp3'
                    self.config.save()
            return success, message
            
        elif self.device_type == 'ssp5a':
            print(f"[SSP] Using manual SSP5A timing (no progressive fallback)")
            # Try SSP5A timing only
            success, message = self._try_connect_with_params(
                com_port_number, 
                boot_delay=5.0,  # Full Arduino boot delay
                wait_iterations=40,  # 2 seconds total
                description="SSP5A timing (manual)"
            )
            if success:
                self.detected_device_type = 'ssp5a'
                if self.config:
                    self.config.config['detected_device_type'] = 'ssp5a'
                    self.config.save()
            return success, message
        
        else:  # 'auto' mode - progressive fallback
            print(f"[SSP] Using auto detection with progressive fallback")
            
            # First attempt: SSP3 timing (minimal delay, original SSPDataq timing)
            print(f"[SSP] First attempt: Trying SSP3 timing...")
            success, message = self._try_connect_with_params(
                com_port_number, 
                boot_delay=0.5,  # Minimal delay for SSP3
                wait_iterations=100,  # Original SSPDataq: 100 iterations × 50ms = 5 seconds
                description="SSP3 timing (first attempt)"
            )
            
            if success:
                print(f"[SSP] SUCCESS: Device detected as SSP3 (fast response)")
                self.detected_device_type = 'ssp3'
                if self.config:
                    self.config.config['detected_device_type'] = 'ssp3'
                    self.config.save()
                return success, message
            
            # Second attempt: SSP5A timing (full boot delay)
            print(f"[SSP] First attempt failed, trying SSP5A timing...")
            success, message = self._try_connect_with_params(
                com_port_number, 
                boot_delay=5.0,  # Full Arduino boot delay
                wait_iterations=40,  # 40 iterations × 50ms = 2 seconds
                description="SSP5A timing (second attempt)"
            )
            
            if success:
                print(f"[SSP] SUCCESS: Device detected as SSP5A (requires boot delay)")
                self.detected_device_type = 'ssp5a'
                if self.config:
                    self.config.config['detected_device_type'] = 'ssp5a'
                    self.config.save()
                return success, message
            
            # Both attempts failed
            print(f"[SSP] ERROR: Both connection attempts failed")
            return (False, "Not connected - no response from SSP with either timing. Check power and connections.")
    
    def disconnect(self):
        """Disconnect from SSP photometer.
        
        Implements the disconnection sequence from SSPDataq:
        1. Send "SEEEEE" command to exit serial mode
        2. Close COM port
        
        Returns:
            tuple: (success: bool, message: str)
        """
        if not self.is_connected:
            return (False, "Not connected")
        
        try:
            # Send exit command
            self._write("SEEEEE")
            time.sleep(0.1)  # Brief pause
            
            # Close port
            if self.port and self.port.IsOpen:
                self.port.Close()
            
            self.port = None
            self.is_connected = False
            return (True, "Disconnected from " + self.port_name)
            
        except Exception as e:
            return (False, "Disconnection failed: " + str(e))
    
    def get_slow_count(self, integration_ms):
        """Get a single count reading in slow mode.
        
        Implements [Get_Counts] subroutine from SSPDataq (lines 2231-2298):
        1. Clear buffer
        2. Send "SCnnnn" command
        3. Wait for integration time with proper overhead (matches original)
        4. Read buffer and extract count after "="
        5. Return 5-digit count value
        
        Original SSPDataq timing:
        - 1 sec (1000ms): Pause 1150ms (15% overhead)
        - 5 sec (5000ms): 5 x 1030ms = 5150ms (3% overhead)
        - 10 sec (10000ms): 10 x 1015ms = 10150ms (1.5% overhead)
        
        Args:
            integration_ms: Integration time in milliseconds (1000, 5000, or 10000)
            
        Returns:
            tuple: (success: bool, count: str or None, error_msg: str)
        """
        if not self.is_connected:
            return (False, None, "Not connected")
        
        try:
            # Clear buffer
            self._clear_buffer()
            
            # Send count command - format: SCnnnn where nnnn is 4-digit integration time
            command = "SC{:04d}".format(integration_ms)
            self._write(command)
            
            # Determine which timing mode to use
            # Manual device_type overrides auto-detected device_type
            if self.device_type != 'auto':
                # Manual mode: use specified type
                use_ssp5a_timing = (self.device_type == 'ssp5a')
            else:
                # Auto mode: use detected type, default to SSP5A for safety
                if self.detected_device_type != 'unknown':
                    use_ssp5a_timing = (self.detected_device_type == 'ssp5a')
                else:
                    # Not yet detected, be conservative and use SSP5A timing
                    use_ssp5a_timing = True
            
            # Only give Arduino a moment to process if using SSP5A timing
            # Original SSPDataq3 code doesn't have this delay for SSP3
            if use_ssp5a_timing:
                time.sleep(0.02)  # 20ms - enough for Arduino to parse command
            
            # Wait for integration time - match original SSPDataq timing exactly
            if integration_ms == 1000:
                wait_time = 1.150  # 1150ms
            elif integration_ms == 5000:
                wait_time = 5.150  # 5 x 1030ms
            elif integration_ms == 10000:
                wait_time = 10.150  # 10 x 1015ms
            else:
                # Fallback for non-standard integration times
                wait_time = integration_ms * 1.15 / 1000.0
            
            time.sleep(wait_time)
            
            # Read response with device-specific timeout
            # Use the same timing mode determined earlier
            # SSP3: Original SSPDataq3 timing (shorter timeout)
            # SSP5A: Longer timeout for Arduino communication
            if use_ssp5a_timing:
                timeout_seconds = 2.0  # Current SSP5A timeout
            else:
                timeout_seconds = 1.0  # Original SSPDataq3 timeout for SSP3
            
            response = self._read_with_timeout(timeout_seconds=timeout_seconds, expected_end='\r\n')
            
            # Find "=" and extract 5 characters after it
            equals_pos = response.find("=")
            
            if equals_pos >= 0 and len(response) >= equals_pos + 6:
                count_str = response[equals_pos + 1:equals_pos + 6]
                
                # Verify first character is not null (error check)
                if count_str and ord(count_str[0]) != 0:
                    return (True, count_str, "")
                else:
                    return (False, None, "Communication error - null character received")
            else:
                return (False, None, "Invalid response format: " + repr(response))
                
        except Exception as e:
            return (False, None, "Error getting count: " + str(e))
    
    def set_integration(self, integration_ms):
        """Set photometer integration time.
        
        Implements integration time setting from SSPDataq (lines 1599-1633):
        1. Send SInnnn command where nnnn is a 4-digit integration value
        2. Wait for "!" acknowledgment (up to 5 seconds)
        
        Integration time mapping (matches SSPDataq [SELECT_INTEG.Click]):
        - 20ms -> SI0002
        - 50ms -> SI0005
        - 100ms -> SI0010
        - 500ms -> SI0050
        - 1000ms -> SI0100
        - 5000ms -> SI0500
        - 10000ms -> SI1000
        
        Args:
            integration_ms: Integration time in milliseconds (20, 50, 100, 500, 1000, 5000, or 10000)
            
        Returns:
            tuple: (success: bool, message: str)
        """
        if not self.is_connected:
            return (False, "Not connected")
        
        # Map integration time to command codes (matches SSPDataq)
        if integration_ms == 20:
            command = "SI0002"
        elif integration_ms == 50:
            command = "SI0005"
        elif integration_ms == 100:
            command = "SI0010"
        elif integration_ms == 500:
            command = "SI0050"
        elif integration_ms == 1000:
            command = "SI0100"
        elif integration_ms == 5000:
            command = "SI0500"
        elif integration_ms == 10000:
            command = "SI1000"
        else:
            return (False, "Invalid integration time. Must be 20, 50, 100, 500, 1000, 5000, or 10000 ms")
        
        try:
            self._clear_buffer()
            self._write(command)
            
            # Wait for acknowledgment (matches original [WaitForAck] routine)
            ack_received = False
            for i in range(100):
                time.sleep(0.05)  # 50ms pause (matches original)
                if self.port.BytesToRead > 0:
                    response = self._read_available()
                    if "!" in response:
                        ack_received = True
                        break
            
            if ack_received:
                return (True, "Integration time set to " + str(integration_ms) + " ms")
            else:
                return (False, "No acknowledgment received from SSP")
                
        except Exception as e:
            return (False, "Error setting integration time: " + str(e))
    
    def set_gain(self, gain_value):
        """Set photometer gain.
        
        Implements gain setting from SSPDataq (lines 1555-1580):
        1. Send SGNNN command (SGNNN3=gain 1, SGNNN2=gain 10, SGNNN1=gain 100)
        2. Wait for "!" acknowledgment (up to 5 seconds)
        
        Args:
            gain_value: Gain value (1, 10, or 100)
            
        Returns:
            tuple: (success: bool, message: str)
        """
        if not self.is_connected:
            return (False, "Not connected")
        
        # Map gain values to command codes (inverted mapping)
        if gain_value == 1:
            command = "SGNNN3"
        elif gain_value == 10:
            command = "SGNNN2"
        elif gain_value == 100:
            command = "SGNNN1"
        else:
            return (False, "Invalid gain value. Must be 1, 10, or 100")
        
        try:
            self._clear_buffer()
            self._write(command)
            
            # Wait for acknowledgment (matches original [WaitForAck] routine)
            ack_received = False
            for i in range(100):
                time.sleep(0.05)  # 50ms pause (matches original)
                if self.port.BytesToRead > 0:
                    response = self._read_available()
                    if "!" in response:
                        ack_received = True
                        break
            
            if ack_received:
                return (True, "Gain set to " + str(gain_value))
            else:
                return (False, "No acknowledgment received from SSP")
                
        except Exception as e:
            return (False, "Error setting gain: " + str(e))
    
    def home_filter(self):
        """Home the filter bar (automatic filter mode).
        
        Implements SHNNN command from SSPDataq (lines 1493-1515).
        Sends "SHNNN" command and waits for "!" acknowledgment with 3 retries.
        
        Returns:
            tuple: (success: bool, retry_count: int, message: str)
        """
        print("\n=== FILTER HOME COMMAND ===")
        print("Connection status: " + ("Connected" if self.is_connected else "Not connected"))
        
        if not self.is_connected:
            print("ERROR: Cannot home filter - not connected to SSP")
            return (False, 0, "Not connected")
        
        if self.port:
            print("COM Port: " + self.port.PortName)
            print("Port open: " + str(self.port.IsOpen))
        
        # Retry up to 3 times if no acknowledgment
        for retry in range(3):
            print("\nAttempt " + str(retry + 1) + " of 3:")
            try:
                print("  Clearing serial buffer...")
                self._clear_buffer()
                
                print("  Sending command: SHNNN")
                self._write("SHNNN")
                
                # Wait for acknowledgment (up to 5 seconds)
                print("  Waiting for acknowledgment (up to 5 seconds)...")
                ack_received = False
                for i in range(100):
                    time.sleep(0.05)  # 50ms pause
                    if self.port.BytesToRead > 0:
                        response = self._read_available()
                        print("  Received: '" + response + "'")
                        if "!" in response:
                            ack_received = True
                            print("  SUCCESS: Acknowledgment received!")
                            break
                
                if ack_received:
                    print("Filter bar successfully homed (attempt " + str(retry + 1) + ")")
                    print("=" * 30)
                    return (True, retry, "Filter bar homed")
                else:
                    print("  WARNING: No acknowledgment received")
                    # No ack, will retry unless this was the last attempt
                    if retry < 2:
                        print("  Pausing 2 seconds before retry...")
                        time.sleep(2.0)  # 2 second pause before retry
                    else:
                        print("  All retries exhausted")
                    
            except Exception as e:
                print("  EXCEPTION: " + str(e))
                print("=" * 30)
                return (False, retry, "Error homing filter: " + str(e))
        
        # All retries failed
        print("FAILED: No acknowledgment received after 3 attempts")
        print("=" * 30)
        return (False, 3, "No acknowledgment received after 3 attempts")
    
    def select_filter(self, filter_number):
        """Select filter position (automatic filter mode).
        
        Implements SFNNN command from SSPDataq (lines 1520-1543).
        Sends "SFNNNn" command where n is 1-6 for filter position.
        Waits for "!" acknowledgment with 3 retries.
        
        Args:
            filter_number: Filter position (1-6)
            
        Returns:
            tuple: (success: bool, retry_count: int, message: str)
        """
        print("\n=== FILTER SELECT COMMAND ===")
        print("Requested position: " + str(filter_number))
        print("Connection status: " + ("Connected" if self.is_connected else "Not connected"))
        
        if not self.is_connected:
            print("ERROR: Cannot select filter - not connected to SSP")
            return (False, 0, "Not connected")
        
        if filter_number < 1 or filter_number > 6:
            print("ERROR: Invalid filter number (must be 1-6)")
            return (False, 0, "Invalid filter number. Must be 1-6")
        
        if self.port:
            print("COM Port: " + self.port.PortName)
            print("Port open: " + str(self.port.IsOpen))
        
        # Retry up to 3 times if no acknowledgment
        for retry in range(3):
            print("\nAttempt " + str(retry + 1) + " of 3:")
            try:
                print("  Clearing serial buffer...")
                self._clear_buffer()
                
                print("  Pausing 10ms...")
                time.sleep(0.01)  # 10ms pause (matches original "call Pause 10")
                
                command = "SFNNN" + str(filter_number)
                print("  Sending command: " + command)
                self._write(command)
                
                # Wait for acknowledgment (up to 5 seconds)
                print("  Waiting for acknowledgment (up to 5 seconds)...")
                ack_received = False
                for i in range(100):
                    time.sleep(0.05)  # 50ms pause
                    if self.port.BytesToRead > 0:
                        response = self._read_available()
                        print("  Received: '" + response + "'")
                        if "!" in response:
                            ack_received = True
                            print("  SUCCESS: Acknowledgment received!")
                            break
                
                if ack_received:
                    print("Filter " + str(filter_number) + " successfully selected (attempt " + str(retry + 1) + ")")
                    print("=" * 30)
                    return (True, retry, "Filter " + str(filter_number) + " selected")
                else:
                    print("  WARNING: No acknowledgment received")
                    # No ack, will retry unless this was the last attempt
                    if retry < 2:
                        print("  Pausing 2 seconds before retry...")
                        time.sleep(2.0)  # 2 second pause before retry
                    else:
                        print("  All retries exhausted")
                    
            except Exception as e:
                print("  EXCEPTION: " + str(e))
                print("=" * 30)
                return (False, retry, "Error selecting filter: " + str(e))
        
        # All retries failed
        print("FAILED: No acknowledgment received after 3 attempts")
        print("=" * 30)
        return (False, 3, "No acknowledgment received after 3 attempts")
    
    def _write(self, data):
        """Write data to serial port.
        
        Args:
            data: String to write
        """
        if self.port and self.port.IsOpen:
            self.port.Write(data)
    
    def _read_with_timeout(self, timeout_seconds=2.0, expected_end='\r\n'):
        """Read from serial port with timeout - OPTIMIZED VERSION.
        
        Optimized for IronPython 2.7 to reduce memory allocations:
        - Uses list accumulation instead of string concatenation
        - Reduces temporary string object creation
        - Improves performance during long data acquisition sessions
        
        Args:
            timeout_seconds: Maximum time to wait for data
            expected_end: String that indicates complete response (default \r\n)
            
        Returns:
            str: Data read from port, or empty string if timeout
        """
        if not self.port or not self.port.IsOpen:
            return ""
        
        import time
        
        start_time = time.time()
        data_parts = []  # Use list instead of string for accumulation
        last_data_time = time.time()
        
        while time.time() - start_time < timeout_seconds:
            # Check if any data is available
            if self.port.BytesToRead > 0:
                chunk = self.port.ReadExisting()
                if chunk:
                    data_parts.append(chunk)  # Append to list (O(1))
                    last_data_time = time.time()
                    
                    # Optimized: Check chunk directly first (common case)
                    if chunk.endswith(expected_end):
                        # Join all parts and return
                        return ''.join(data_parts)
                    
                    # Periodically check if accumulated data ends with expected_end
                    # Only join when we have enough parts to avoid frequent joining
                    if len(data_parts) >= 5:  # Check every 5 chunks
                        data = ''.join(data_parts)
                        if data.endswith(expected_end):
                            return data
                
                # Small sleep to avoid tight loop
                time.sleep(0.001)  # 1ms
            else:
                # If we got some data but nothing new for 100ms, return what we have
                if data_parts and (time.time() - last_data_time) > 0.1:
                    return ''.join(data_parts)
                    
                # No data yet, sleep a bit
                time.sleep(0.01)  # 10ms
        
        # Timeout reached - join any collected parts
        return ''.join(data_parts) if data_parts else ""
    
    def _read_available(self):
        """Read all available data from serial port.
        
        Returns:
            str: Data read from port
        """
        if self.port and self.port.IsOpen and self.port.BytesToRead > 0:
            return self.port.ReadExisting()
        return ""
    
    def _clear_buffer(self):
        """Clear the serial port input buffer."""
        if self.port and self.port.IsOpen:
            # Read and discard any data in buffer
            while self.port.BytesToRead > 0:
                self.port.ReadExisting()
